package com.surveyquant.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
                uploadCallback = cb;
                Intent i = p.createIntent(); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(i, 1001); } catch(Exception e){ uploadCallback=null; return false; }
                return true;
            }
        });
        setContentView(web); web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d); if(r==1001 && uploadCallback!=null){ uploadCallback.onReceiveValue(c==RESULT_OK && d!=null ? new Uri[]{d.getData()} : null); uploadCallback=null; }
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
